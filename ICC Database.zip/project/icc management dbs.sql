-- -----------------------------------------------------
-- Schema ICC
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `ICC` ;
SHOW WARNINGS;
USE `ICC` ;

-- -----------------------------------------------------
-- Table `ICC`.`Team`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ICC`.`Team` (
  `team_id` INT NOT NULL AUTO_INCREMENT,
  `team_name` VARCHAR(45) NOT NULL UNIQUE,
  check(`team_name` not like '%[0-9]%'),
  PRIMARY KEY (`team_id`))
ENGINE = InnoDB;

SHOW WARNINGS;
CREATE UNIQUE INDEX `team_id_UNIQUE` ON `ICC`.`Team` (`team_id` ASC) VISIBLE;

SHOW WARNINGS;
CREATE UNIQUE INDEX `team_name_UNIQUE` ON `ICC`.`Team` (`team_name` ASC) VISIBLE;

SHOW WARNINGS;

-- -----------------------------------------------------
-- Table `ICC`.`Person`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ICC`.`Person` (
  `person_id` INT NOT NULL AUTO_INCREMENT,
  `first_name` VARCHAR(45) NOT NULL,
  check(`first_name` not like '%[0-9]%'),
  `last_name` VARCHAR(45) NOT NULL,
  check(`last_name` not like '%[0-9]%'),
  `birth_year` INT NOT NULL,
  check(`birth_year`>=1900),
  `height` FLOAT NOT NULL,
  check(`height` >=5.0),
  `birth_place` VARCHAR(45) NOT NULL,
  check(`birth_place` not like '%[0-9]%'),
  PRIMARY KEY (`person_id`))
ENGINE = InnoDB;

SHOW WARNINGS;

-- -----------------------------------------------------
-- Table `ICC`.`Player`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ICC`.`Player` (
  `player_id` INT NOT NULL,
  `team_id` INT NOT NULL,
  `role` VARCHAR(45) NOT NULL,
  check(`role` = "wicket keeper" or `role` = "all-rounder" or `role` = "batsman" or `role` = "bowler"),
  `shirt_no` INT NOT NULL,
  check(`shirt_no` >0),
  `batting_style` VARCHAR(45) not NULL,
  check(`batting_style`="left hand" or `batting_style`= "right hand" ),
  `bowling_style` VARCHAR(45) not NULL,
  check(`bowling_style`="left hand" or `bowling_style`= "right hand" ),
  `status` CHAR(7) NOT NULL,
  check(`bowling_style`!=null or `batting_style` = null and `batting_style`!=null or `bowling_style` = null ),
  check(`status`= "retired" or `status`="playing"),
  PRIMARY KEY (`player_id`),
  CONSTRAINT `fk_Player_Person`
    FOREIGN KEY (`player_id`)
    REFERENCES `ICC`.`Person` (`person_id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `fk_Player_Team1`
    FOREIGN KEY (`team_id`)
    REFERENCES `ICC`.`Team` (`team_id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB;

SHOW WARNINGS;
CREATE INDEX `fk_Player_Person_idx` ON `ICC`.`Player` (`player_id` ASC) VISIBLE;

SHOW WARNINGS;
CREATE INDEX `fk_Player_Team1_idx` ON `ICC`.`Player` (`team_id` ASC) VISIBLE;

SHOW WARNINGS;

-- -----------------------------------------------------
-- Table `ICC`.`Staff`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ICC`.`Staff` (
  `staff_id` INT NOT NULL,
  `team_id` INT NOT NULL,
  `designation` VARCHAR(45) NOT NULL,
  check(`designation` = "driver" or `designation` = "head coach" or `designation` = "bowling coach" or
  `designation` = "batting coach" or `designation` = "fielding coach" or 
  `designation` = "cook" or `designation` = "physio" or `designation` = "doctor"),
  PRIMARY KEY (`staff_id`),
  CONSTRAINT `fk_Staff_Person1`
    FOREIGN KEY (`staff_id`)
    REFERENCES `ICC`.`Person` (`person_id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `fk_Staff_Team1`
    FOREIGN KEY (`team_id`)
    REFERENCES `ICC`.`Team` (`team_id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB;

SHOW WARNINGS;
CREATE INDEX `fk_Staff_Team1_idx` ON `ICC`.`Staff` (`team_id` ASC) VISIBLE;

SHOW WARNINGS;

-- -----------------------------------------------------
-- Table `ICC`.`Umpire`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ICC`.`Umpire` (
  `umpire_id` INT NOT NULL,
  `start` INT NOT NULL,
  check(`start`>1900),
  `till` INT default NULL,
  check(`till`>=`start`),
  PRIMARY KEY (`umpire_id`),
  CONSTRAINT `fk_Umpire_Person1`
    FOREIGN KEY (`umpire_id`)
    REFERENCES `ICC`.`Person` (`person_id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB;

SHOW WARNINGS;

-- -----------------------------------------------------
-- Table `ICC`.`Squad`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ICC`.`Squad` (
  `squad_id` INT NOT NULL AUTO_INCREMENT,
  `match_type` VARCHAR(20) NOT NULL,
  check (`match_type` = "odi" or `match_type` = "t20" or `match_type` = "test"), 
  `Team_team_id` INT NOT NULL,
  PRIMARY KEY (`squad_id`),
  CONSTRAINT `fk_Squad_Team1`
    FOREIGN KEY (`Team_team_id`)
    REFERENCES `ICC`.`Team` (`team_id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB;

SHOW WARNINGS;
CREATE INDEX `fk_Squad_Team1_idx` ON `ICC`.`Squad` (`Team_team_id` ASC) VISIBLE;

SHOW WARNINGS;

-- -----------------------------------------------------
-- Table `ICC`.`Record`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ICC`.`Record` (
  `record_name` VARCHAR(45) NOT NULL,
  check (`record_name` = "most runs" or `record_name` = "most centuries" or `record_name` = "most half centuries"
  or `record_name` = "highest runs" or `record_name` = "highest average" or `record_name` = "most hattricks"
  or `record_name` = "most wickets" or `record_name` = "most 5Ws" or
  `record_name` = "best bowling average" or `record_name` = "most games"),
  `record_format` VARCHAR(4) NOT NULL,
  check (`record_format` = "odi" or `record_format` = "t20" or `record_format` = "test"), 
  `against_team` INT NOT NULL,
  `Player_player_id` INT NOT NULL,
  `year` INT NOT NULL,
  check(`year`>=1900),
  PRIMARY KEY (`record_name`, `record_format`),
  CONSTRAINT `fk_Hall of Fame_Team1`
    FOREIGN KEY (`against_team`)
    REFERENCES `ICC`.`Team` (`team_id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `fk_Hall of Fame_Player1`
    FOREIGN KEY (`Player_player_id`)
    REFERENCES `ICC`.`Player` (`player_id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB;

SHOW WARNINGS;
CREATE INDEX `fk_Hall of Fame_Team1_idx` ON `ICC`.`Record` (`against_team` ASC) VISIBLE;

SHOW WARNINGS;
CREATE INDEX `fk_Hall of Fame_Player1_idx` ON `ICC`.`Record` (`Player_player_id` ASC) VISIBLE;

SHOW WARNINGS;

-- -----------------------------------------------------
-- Table `ICC`.`Format`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ICC`.`Format` (
  `Player_player_id` INT NOT NULL,
  `Squad_squad_id` INT NOT NULL,
  `match_type` VARCHAR(4) NOT NULL,
  check (`match_type` = "odi" or `match_type` = "t20" or `match_type` = "test"), 
  PRIMARY KEY (`Player_player_id`, `Squad_squad_id`),
  CONSTRAINT `fk_Player_has_Squad_Player1`
    FOREIGN KEY (`Player_player_id`)
    REFERENCES `ICC`.`Player` (`player_id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `fk_Player_has_Squad_Squad1`
    FOREIGN KEY (`Squad_squad_id`)
    REFERENCES `ICC`.`Squad` (`squad_id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB;

SHOW WARNINGS;
CREATE INDEX `fk_Player_has_Squad_Squad1_idx` ON `ICC`.`Format` (`Squad_squad_id` ASC) VISIBLE;

SHOW WARNINGS;
CREATE INDEX `fk_Player_has_Squad_Player1_idx` ON `ICC`.`Format` (`Player_player_id` ASC) VISIBLE;

SHOW WARNINGS;

-- -----------------------------------------------------
-- Table `ICC`.`Career`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ICC`.`Career` (
  `Career_id` INT NOT NULL AUTO_INCREMENT,
  `Player_player_id` INT NOT NULL,
  `match_type` VARCHAR(45) NOT NULL,
  check (`match_type` = "odi" or `match_type` = "t20" or `match_type` = "test"), 
  `matches_played` INT NOT NULL DEFAULT 0,
  check(`matches_played`>=0),
  PRIMARY KEY (`Career_id`),
  CONSTRAINT `fk_Career_Player1`
    FOREIGN KEY (`Player_player_id`)
    REFERENCES `ICC`.`Player` (`player_id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB;

SHOW WARNINGS;

-- -----------------------------------------------------
-- Table `ICC`.`Batting_career`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ICC`.`Batting_career` (
  `Career_Career_id` INT NOT NULL,
  `innings` INT NOT NULL DEFAULT 0,
  `not-out` INT NOT NULL DEFAULT 0,
  `runs` INT NOT NULL DEFAULT 0,
  `high_score` INT NOT NULL DEFAULT 0,
  `Avg` FLOAT NOT NULL DEFAULT 0,
  `strike_rate` FLOAT NOT NULL DEFAULT 0,
  `boundaries` INT NOT NULL DEFAULT 0,
  `50s` INT NOT NULL DEFAULT 0,
  `100s` INT NOT NULL DEFAULT 0,
  CHECK(`innings` >=0 AND `not-out`>=0 AND `high_score`>=0 AND`Avg`>=0
  AND`strike_rate`>=0 AND`boundaries`>=0 AND`50s`>=0 AND`100s`>=0),
  PRIMARY KEY (`Career_Career_id`),
  CONSTRAINT `fk_Batting_career_Career1`
    FOREIGN KEY (`Career_Career_id`)
    REFERENCES `ICC`.`Career` (`Career_id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB;

SHOW WARNINGS;

-- -----------------------------------------------------
-- Table `ICC`.`Bowling_career`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ICC`.`Bowling_career` (
  `Career_Career_id` INT NOT NULL,
  `innings` INT NOT NULL,
  `overs` FLOAT NOT NULL DEFAULT 0,
  `runs` INT NOT NULL DEFAULT 0,
  `wickets` INT NOT NULL DEFAULT 0,
  `Avg` FLOAT NOT NULL DEFAULT 0,
  `strike_rate` FLOAT NOT NULL DEFAULT 0,
  `economy` FLOAT NOT NULL DEFAULT 0,
  `5Ws` INT NOT NULL DEFAULT 0,
  `10Ws` INT NOT NULL DEFAULT 0,
   CHECK(`innings` >=0 AND `overs`>=0 AND `runs`>=0 AND`Avg`>=0 AND `strike_rate`>=0
  AND`strike_rate`>=0 AND`wickets`>=0 AND`5Ws`>=0 AND`10Ws`>=0),
  PRIMARY KEY (`Career_Career_id`),
  CONSTRAINT `fk_Bowling_career_Career1`
    FOREIGN KEY (`Career_Career_id`)
    REFERENCES `ICC`.`Career` (`Career_id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB;

SHOW WARNINGS;

-- -----------------------------------------------------
-- Table `ICC`.`Stadium`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ICC`.`Stadium` (
  `std_id` INT NOT NULL AUTO_INCREMENT,
  `std_name` VARCHAR(80) NOT NULL,
  check(`std_name` not like '%[0-9]%'),
  `country` VARCHAR(45) NOT NULL,
  check(`country` not like '%[0-9]%'),
  `capacity` INT NOT NULL,
  check(`capacity`>=5000),
  PRIMARY KEY (`std_id`))
ENGINE = InnoDB;

SHOW WARNINGS;

-- -----------------------------------------------------
-- Table `ICC`.`Matches`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ICC`.`Matches` (
  `match_id` INT NOT NULL AUTO_INCREMENT,
  `match_type` VARCHAR(4) NOT NULL,
  check (`match_type` = "odi" or `match_type` = "t20" or `match_type` = "test"), 
  `year` INT NOT NULL,
  check(`year`>=1900),
  `Squad_squad_id1` INT NOT NULL,
  `Squad_squad_id2` INT NOT NULL,
  `winner` INT NOT NULL DEFAULT 0,
  check(`winner`=1 or `winner`=2 or `winner`= 0 or `winner`=-1),
  `Stadium_std_id` INT NOT NULL,
  PRIMARY KEY (`match_id`, `match_type`),
  CONSTRAINT `fk_Matches_Squad2`
    FOREIGN KEY (`Squad_squad_id1`)
    REFERENCES `ICC`.`Squad` (`squad_id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `fk_Matches_Stadium1`
    FOREIGN KEY (`Stadium_std_id`)
    REFERENCES `ICC`.`Stadium` (`std_id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `fk_Matches_Squad1`
    FOREIGN KEY (`Squad_squad_id2`)
    REFERENCES `ICC`.`Squad` (`squad_id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB;

SHOW WARNINGS;
CREATE INDEX `fk_Matches_Squad2_idx` ON `ICC`.`Matches` (`Squad_squad_id1` ASC) VISIBLE;

SHOW WARNINGS;
CREATE INDEX `fk_Matches_Stadium1_idx` ON `ICC`.`Matches` (`Stadium_std_id` ASC) VISIBLE;

SHOW WARNINGS;
CREATE INDEX `fk_Matches_Squad1_idx` ON `ICC`.`Matches` (`Squad_squad_id2` ASC) VISIBLE;

SHOW WARNINGS;

-- -----------------------------------------------------
-- Table `ICC`.`WC_Matches`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ICC`.`WC_Matches` (
  `WC_id` INT NOT NULL auto_increment,
  `Matches_match_id` INT NOT NULL,
  `Matches_match_type` VARCHAR(20) NOT NULL,
  PRIMARY KEY (`WC_id`, `Matches_match_id`, `Matches_match_type`),
  CONSTRAINT `fk_WC_Matches_Matches1`
    FOREIGN KEY (`Matches_match_id` , `Matches_match_type`)
    REFERENCES `ICC`.`Matches` (`match_id` , `match_type`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB;

SHOW WARNINGS;
CREATE INDEX `fk_WC_Matches_Matches1_idx` ON `ICC`.`WC_Matches` (`Matches_match_id` ASC, `Matches_match_type` ASC) VISIBLE;

SHOW WARNINGS;

-- -----------------------------------------------------
-- Table `ICC`.`WC_standings`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ICC`.`WC_standings` (
  `WC_Matches_WC_id` INT NOT NULL ,
  `match_id` INT NOT NULL,
  `stage` VARCHAR(45) NOT NULL,
  check(stage = "group-stage" or stage = "semifinal" or stage = "final"),
  PRIMARY KEY (`WC_Matches_WC_id`, `match_id`),
  CONSTRAINT `fk_table1_WC_Matches1`
    FOREIGN KEY (`WC_Matches_WC_id` , `match_id`)
    REFERENCES `ICC`.`WC_Matches` (`WC_id` , `Matches_match_id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB;

SHOW WARNINGS;

-- -----------------------------------------------------
-- Table `ICC`.`Umpiring`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ICC`.`Umpiring` (
  `Umpire_umpire_id` INT NOT NULL,
  `Matches_match_id` INT NOT NULL,
  `Matches_match_type` VARCHAR(20) NOT NULL,
  `role` VARCHAR(45) NOT NULL,
  check(`role` = "1st-umpire" or `role` = "2nd-umpire" or `role` = "3rd-upmire"),
  PRIMARY KEY (`Umpire_umpire_id`, `Matches_match_id`, `Matches_match_type`),
  CONSTRAINT `fk_Umpire_has_Matches_Umpire1`
    FOREIGN KEY (`Umpire_umpire_id`)
    REFERENCES `ICC`.`Umpire` (`umpire_id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `fk_Umpiring_Matches1`
    FOREIGN KEY (`Matches_match_id` , `Matches_match_type`)
    REFERENCES `ICC`.`Matches` (`match_id` , `match_type`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB;

SHOW WARNINGS;
CREATE INDEX `fk_Umpire_has_Matches_Umpire1_idx` ON `ICC`.`Umpiring` (`Umpire_umpire_id` ASC) VISIBLE;

SHOW WARNINGS;
CREATE INDEX `fk_Umpiring_Matches1_idx` ON `ICC`.`Umpiring` (`Matches_match_id` ASC, `Matches_match_type` ASC) VISIBLE;

SHOW WARNINGS;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `icc`.`all_umpires` AS select `icc`.`person`.`first_name` AS `first_name`,`icc`.`person`.`last_name` AS `last_name`,`icc`.`umpire`.`start` AS `start`,`icc`.`umpire`.`till` AS `till` from (`icc`.`person` join `icc`.`umpire` on((`icc`.`umpire`.`umpire_id` = `icc`.`person`.`person_id`)));

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `icc`.`upcoming_matches` AS select row_number() OVER (ORDER BY (select 1) )  AS `s/no`,`icc`.`matches`.`match_id` AS `match_id`,`icc`.`matches`.`match_type` AS `match_type`,`icc`.`matches`.`match_year` AS `match_year`,`a`.`team_1` AS `team_1`,`b`.`team_2` AS `team_2`,`icc`.`stadium`.`std_name` AS `std_name` from (((`icc`.`matches` join `icc`.`stadium` on((`icc`.`matches`.`Stadium_std_id` = `icc`.`stadium`.`std_id`))) join (select `icc`.`team`.`team_name` AS `team_1` from ((`icc`.`matches` join `icc`.`squad` on((`icc`.`matches`.`Squad_squad_id1` = `icc`.`squad`.`squad_id`))) join `icc`.`team` on((`icc`.`team`.`team_id` = `icc`.`squad`.`Team_team_id`)))) `a`) join (select `icc`.`team`.`team_name` AS `team_2` from ((`icc`.`matches` join `icc`.`squad` on((`icc`.`matches`.`Squad_squad_id2` = `icc`.`squad`.`squad_id`))) join `icc`.`team` on((`icc`.`team`.`team_id` = `icc`.`squad`.`Team_team_id`)))) `b`) group by `icc`.`matches`.`match_id`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `icc`.`upcoming_worldcup` AS select `icc`.`wc_matches`.`Matches_match_type` AS `Matches_match_type`,`icc`.`upcoming_matches`.`match_year` AS `match_year`,`icc`.`upcoming_matches`.`team_1` AS `team_1`,`icc`.`upcoming_matches`.`team_2` AS `team_2`,`icc`.`upcoming_matches`.`std_name` AS `std_name`,`icc`.`wc_standings`.`stage` AS `stage` from ((`icc`.`upcoming_matches` join `icc`.`wc_matches` on((`icc`.`upcoming_matches`.`match_id` = `icc`.`wc_matches`.`Matches_match_id`))) join `icc`.`wc_standings` on((`icc`.`wc_matches`.`WC_id` = `icc`.`wc_standings`.`WC_Matches_WC_id`)));

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `icc`.`view_record` AS select `r`.`record_name` AS `record_name`,`r`.`record_format` AS `record_format`,`p`.`player_name` AS `player_name`,`p`.`team_name` AS `team_name`,`r`.`team_name` AS `against_name`,`r`.`year` AS `year` from ((select concat(`icc`.`person`.`first_name`,' ',`icc`.`person`.`last_name`) AS `player_name`,`icc`.`team`.`team_name` AS `team_name`,`icc`.`player`.`player_id` AS `player_id` from ((`icc`.`player` join `icc`.`person`) join `icc`.`team` on(((`icc`.`player`.`player_id` = `icc`.`person`.`person_id`) and (`icc`.`player`.`team_id` = `icc`.`team`.`team_id`))))) `p` join (select `icc`.`record`.`record_name` AS `record_name`,`icc`.`record`.`record_format` AS `record_format`,`icc`.`record`.`against_team` AS `against_team`,`icc`.`record`.`Player_player_id` AS `Player_player_id`,`icc`.`record`.`year` AS `year`,`icc`.`team`.`team_id` AS `team_id`,`icc`.`team`.`team_name` AS `team_name` from (`icc`.`record` join `icc`.`team` on((`icc`.`team`.`team_id` = `icc`.`record`.`against_team`)))) `r` on((`p`.`player_id` = `r`.`Player_player_id`)));
DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_formatsquad`(matchtype varchar(4),teamid int,p1 int,p2 int,p3 int,p4 int,p5 int,p6 int,p7 int,p8 int,p9 int,p10 int,p11 int,p12 int,p13 int,p14 int,p15 int)
BEGIN
	set @sqdid=0;
	insert into squad(match_type,team_team_id) values (matchtype,teamid);
    set @sqd_id = (select max(squad_id) from squad);
    insert into squad_format values (p1,@sqd_id,matchtype),
    (p2,@sqd_id,matchtype),
    (p3,@sqd_id,matchtype),
    (p4,@sqd_id,matchtype),
    (p5,@sqd_id,matchtype),
    (p6,@sqd_id,matchtype),
    (p7,@sqd_id,matchtype),
    (p8,@sqd_id,matchtype),
    (p9,@sqd_id,matchtype),
    (p10,@sqd_id,matchtype),
    (p11,@sqd_id,matchtype),
    (p12,@sqd_id,matchtype),
    (p13,@sqd_id,matchtype),
    (p14,@sqd_id,matchtype),
	(p15,@sqd_id,matchtype);
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_player`(fname varchar(45),lname varchar(45),plyrRole varchar(45),b_year int,b_place varchar(45),batstyle varchar(45),bowlstyle varchar(45),h float,t_id int,shirtNo int,s char(7))
BEGIN
	insert into person(first_name,last_name,birth_year,height,birth_place) values (fname,lname,b_year,h,b_place);
    set @plyr_id=0;
    set @plyr_id =(select max(person_id)from person);
    insert into player values(@plyr_id,t_id,plyrRole,shirtNo,batstyle,bowlstyle,s);
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_staff`(fname varchar(45),lname varchar(45),desig varchar(45),b_year int,b_place varchar(45),h float,t_id int)
BEGIN
	insert into person(first_name,last_name,birth_year,height,birth_place) values (fname,lname,b_year,h,b_place);
    set @staff_id=0;
    set @staff_id =(select max(person_id)from person);
    insert into staff values(@staff_id,t_id,desig);
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_umpire`(fname varchar(45),lname varchar(45),b_year int,b_place varchar(45),h float, s_date int, t_date int)
BEGIN
	insert into person(first_name,last_name,birth_year,height,birth_place) values (fname,lname,b_year,h,b_place);
    set @ump_id=0;
    set @ump_id =(select max(person_id)from person);
    insert into umpire values(@ump_id, s_date, t_date);
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `availble_player`(id integer )
BEGIN
	 select concat(first_name," ",last_name) as "Name", player_id from player join person on player.player_id=person.person_id
     where team_id = id and status="playing";
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `countAvailablePlayers`(teamid int)
BEGIN
	select count(player_id) from player join person on player.player_id=person.person_id
     where team_id = teamid and status="playing";
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_squad`(sqd_id int)
BEGIN
	select first_name,last_name,(YEAR(CURRENT_DATE)- person.birth_year) as Age,height,`role`,batting_style,bowling_style,shirt_no
    from (player join person on player_id=person_id)
    where player_id in (select player_player_id from squad_format where Squad_squad_id=sqd_id);
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_squadid`(teamid int, matchType varchar(4))
BEGIN
	select max(squad_id) from squad where Team_team_id =teamid and match_type=matchtype;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `getTeam_id`(in team varchar(40), out teamid int)
BEGIN
	set teamid= (select team_id from team where team_name=team);
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `make_batting_bowling`(car_id int)
BEGIN
	insert into batting_career(Career_Career_id) value (car_id);
    insert into bowling_career(Career_Career_id) value (car_id);
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `Make_Career`(id integer)
BEGIN
	insert into Career(Player_player_id,match_type,Matches_played) value (id,"t20",0);
    set @a=(select max(Career.Career_id) from career);
    call icc.make_batting_bowling(@a);
    insert into Career(Player_player_id,match_type,Matches_played) value (id,"odi",0);
    set @a=(select max(Career.Career_id) from career);
    call icc.make_batting_bowling(@a);
    insert into Career(Player_player_id,match_type,Matches_played) value (id,"test",0);
    set @a=(select max(Career.Career_id) from career);
    call icc.make_batting_bowling(@a);
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `match_fixture`(sqd_1 int, sqd_2 int,ump_id1 int,ump_id2 int,ump_id3 int,matchType varchar(4),yr int,stdid int)
BEGIN
	set @a=0;
	insert into matches(match_type,match_year,Squad_squad_id1,Squad_squad_id2,Stadium_std_id) values(matchType,yr,sqd_1,sqd_2,stdid);
    set @a=(select max(match_id) from matches);
    insert into umpiring values (ump_id1,@a,matchType,"1st-umpire"),
    (ump_id2,@a,matchType,"2nd-umpire"),
    (ump_id3,@a,matchType,"3rd-upmire");
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `Player_personal_info`(plyr_name varchar(80))
BEGIN
	select person.first_name,person.last_name,(YEAR(CURRENT_DATE)- person.birth_year) as Age, person.Birth_place, team.Team_name, player.batting_style, player.bowling_style, player.shirt_no
    from (player join person on player_id=person.person_id) join team on player.team_id= team.team_id
    where concat(first_name," ",last_name) like concat('%',plyr_name,'%')
    limit 10;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `retired_players`(t_id int)
BEGIN
	select player_id,concat(first_name," ",last_name) 
    from person join player on person_id=player_id 
    where `status`="retired";
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `show_battingCareer_info`(plr_id int)
BEGIN
    select  match_type,matches_played,innings,runs,`avg`,high_score,strike_rate,`50s`,`100s` 
    from batting_career join career 
    on Career_id=Career_Career_id 
    where Player_player_id =plr_id ;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `show_bowlingCareer_info`(plr_id int)
BEGIN
    select  match_type,matches_played,innings,overs,runs,wickets,strike_rate,`Avg`,economy 
    from bowling_career join career 
    on Career_id=Career_Career_id 
    where Player_player_id =plr_id ;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `show_match_info`(mt_id int)
BEGIN
	select * from upcoming_matches where match_id=mt_id;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `show_staff`(teamid int)
BEGIN
	select person.first_name,person.last_name,(YEAR(CURRENT_DATE)- person.birth_year) as Age, team.Team_name,staff.designation, person.Birth_place
    from (staff join person on staff_id=person.person_id) join team on staff.team_id= team.team_id 
    where team.team_id =teamid
    limit 10;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `show_TeamStats`(teamid int)
BEGIN
	select a.`Total Matches`,b.`Wins`,c.`losses`,(a.`Total Matches`-b.`Wins`-c.`losses`) as draw,`Wins`/`Total Matches` as winrate 
    from (select count(match_id) as "Total Matches" from matches where (Squad_squad_id1 in 
    (select squad_id from squad where Team_team_id =teamid) and winner!=0) or 
    (Squad_squad_id2 in (select squad_id from squad where Team_team_id =teamid) and winner!=0)) a,
(select count(match_id) as "Wins" from matches where 
	(Squad_squad_id1 in (select squad_id from squad where Team_team_id =teamid) and winner=1) or 
	(Squad_squad_id2 in (select squad_id from squad where Team_team_id =teamid) and winner=2)) b,
(select count(match_id) as Losses from matches where 
	(Squad_squad_id1 in (select squad_id from squad where Team_team_id =teamid) and winner=2) or 
	(Squad_squad_id2 in (select squad_id from squad where Team_team_id =teamid) and winner=1)) c;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_batting`(plyr_id int,matchtype varchar(4),t_matches int,inn int ,bound int,run int, n_out int, fifty int,ave float,s_rate float,hund int, highscore int)
BEGIN
	set @cr_id =0;
    set @cr_id=(select career_id from career where Player_player_id=plyr_id and match_type=matchtype);
    update career set matches_played=t_matches where career_id=@cr_id;
    update batting_career set innings =inn, 
not_out= n_out ,
runs =run, 
high_score =highscore,
`Avg` = ave,
strike_rate =s_rate, 
boundaries =bound, 
`50s` =fifty ,
`100s`=hund
where Career_Career_id=@cr_id;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_bowling`(plyr_id int,matchtype varchar(4),t_matches int,inn int,ove float,run int,wic int,ave float,s_rate float,ec float,fiv int,ten int)
BEGIN
	set @cr_id =0;
    set @cr_id=(select career_id from career where Player_player_id=plyr_id and match_type=matchtype);
    update career set matches_played=t_matches where career_id=@cr_id;
    update bowling_career set innings =inn, 
overs =ove, 
runs =run, 
wickets =wic, 
`Avg`=ave ,
strike_rate = s_rate ,
economy =ec, 
`5Ws` = fiv, 
`10Ws` =ten 
where Career_Career_id=@cr_id;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_match`(mt_id int,win int,std_id int,yr int)
BEGIN
	update matches set winner=win,Stadium_std_id=std_id,`match_year`=yr where match_id=mt_id;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_player`(plyr_id int,fname varchar(45),lname varchar(45),plyrRole varchar(45),b_year int,b_place varchar(45),batstyle varchar(45),bowlstyle varchar(45),h float,t_id int,shirtNo int,s char(7))
BEGIN
	update person set first_name=fname ,last_name =lname ,birth_year=b_year,height=h,birth_place=b_place where person_id=plyr_id;
    update player set team_id=t_id,`role`=plyrRole,shirt_no=shirtNo,batting_style=batstyle,bowling_style=bowlstyle,`status`=s where player_id = plyr_id;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_record`(player_id int,Vs_id int,y int,rname varchar(80), rformat varchar(40))
BEGIN
	update record set against_team = Vs_id, Player_player_id = player_id,`year` = y where
    record_name = rname and record_format = rformat;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_stadium`(stad_id int,sname varchar(80),cname varchar(45),c int)
BEGIN
	update stadium set std_name=sname ,country =cname ,capacity=c where stad_id=std_id;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_umpire`(ump_id int,fname varchar(45),lname varchar(45),b_year int,b_place varchar(45),h float,s_year int,t_year int)
BEGIN
	update person set first_name=fname ,last_name =lname ,birth_year=b_year,height=h,birth_place=b_place where person_id=ump_id;
    update umpire set `start`=s_year,`till`=t_year;
END$$
DELIMITER ;
