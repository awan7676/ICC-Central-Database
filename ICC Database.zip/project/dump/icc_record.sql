-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: localhost    Database: icc
-- ------------------------------------------------------
-- Server version	8.0.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `record`
--

DROP TABLE IF EXISTS `record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `record` (
  `record_name` varchar(45) NOT NULL,
  `record_format` varchar(4) NOT NULL,
  `against_team` int NOT NULL,
  `Player_player_id` int NOT NULL,
  `year` int NOT NULL,
  PRIMARY KEY (`record_name`,`record_format`),
  KEY `fk_Hall of Fame_Team1_idx` (`against_team`),
  KEY `fk_Hall of Fame_Player1_idx` (`Player_player_id`),
  CONSTRAINT `fk_Hall of Fame_Player1` FOREIGN KEY (`Player_player_id`) REFERENCES `player` (`player_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_Hall of Fame_Team1` FOREIGN KEY (`against_team`) REFERENCES `team` (`team_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `record_chk_1` CHECK (((`record_name` = _utf8mb4'most runs') or (`record_name` = _utf8mb4'most centuries') or (`record_name` = _utf8mb4'most half centuries') or (`record_name` = _utf8mb4'highest runs') or (`record_name` = _utf8mb4'highest average') or (`record_name` = _utf8mb4'most hattricks') or (`record_name` = _utf8mb4'most wickets') or (`record_name` = _utf8mb4'most 5Ws') or (`record_name` = _utf8mb4'best bowling average') or (`record_name` = _utf8mb4'most games'))),
  CONSTRAINT `record_chk_2` CHECK (((`record_format` = _utf8mb4'odi') or (`record_format` = _utf8mb4't20') or (`record_format` = _utf8mb4'test'))),
  CONSTRAINT `record_chk_3` CHECK ((`year` >= 1900))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `record`
--

LOCK TABLES `record` WRITE;
/*!40000 ALTER TABLE `record` DISABLE KEYS */;
INSERT INTO `record` VALUES ('best bowling average','odi',10,180,1999),('best bowling average','t20',6,121,2016),('best bowling average','test',16,447,2012),('highest average','odi',13,85,2002),('highest average','t20',15,316,2012),('highest average','test',8,459,1999),('highest runs','odi',5,156,2012),('highest runs','t20',6,110,2018),('highest runs','test',3,94,2003),('most 5Ws','odi',8,364,2012),('most 5Ws','t20',4,370,2017),('most 5Ws','test',14,53,2005),('most centuries','odi',10,85,2009),('most centuries','t20',1,29,2017),('most centuries','test',18,4,1995),('most games','odi',8,117,2014),('most games','t20',1,196,2019),('most games','test',7,72,2000),('most half centuries','odi',7,70,2000),('most half centuries','t20',9,115,2020),('most half centuries','test',11,48,1997),('most hattricks','odi',14,205,2013),('most hattricks','t20',16,90,2019),('most hattricks','test',17,8,2011),('most runs','odi',12,74,2010),('most runs','t20',4,7,2015),('most runs','test',2,41,2012),('most wickets','odi',9,201,2015),('most wickets','t20',10,83,2021),('most wickets','test',2,312,1998);
/*!40000 ALTER TABLE `record` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-12-31  8:15:31
