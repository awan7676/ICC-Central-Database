-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: localhost    Database: icc
-- ------------------------------------------------------
-- Server version	8.0.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `squad`
--

DROP TABLE IF EXISTS `squad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `squad` (
  `squad_id` int NOT NULL AUTO_INCREMENT,
  `match_type` varchar(20) NOT NULL,
  `Team_team_id` int NOT NULL,
  PRIMARY KEY (`squad_id`),
  KEY `fk_Squad_Team1_idx` (`Team_team_id`),
  CONSTRAINT `fk_Squad_Team1` FOREIGN KEY (`Team_team_id`) REFERENCES `team` (`team_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `squad_chk_1` CHECK (((`match_type` = _utf8mb4'odi') or (`match_type` = _utf8mb4't20') or (`match_type` = _utf8mb4'test')))
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `squad`
--

LOCK TABLES `squad` WRITE;
/*!40000 ALTER TABLE `squad` DISABLE KEYS */;
INSERT INTO `squad` VALUES (1,'odi',1),(2,'odi',2),(3,'odi',3),(4,'odi',4),(5,'odi',5),(6,'odi',6),(7,'odi',7),(8,'odi',8),(9,'odi',9),(10,'odi',10),(11,'odi',11),(12,'odi',12),(13,'odi',13),(14,'odi',14),(15,'odi',15),(16,'odi',16),(17,'odi',17),(18,'odi',18),(19,'t20',1),(20,'t20',2),(21,'t20',3),(22,'t20',4),(23,'t20',5),(24,'t20',6),(25,'t20',7),(26,'t20',8),(27,'t20',9),(28,'t20',10),(29,'t20',11),(30,'t20',12),(31,'t20',13),(32,'t20',14),(33,'t20',15),(34,'t20',16),(35,'t20',17),(36,'t20',18),(37,'test',1),(38,'test',2),(39,'test',3),(40,'test',4),(41,'test',5),(42,'test',6),(43,'test',7),(44,'test',8),(45,'test',9),(46,'test',10),(47,'test',11),(48,'test',12),(49,'test',13),(50,'test',14),(51,'test',15),(52,'test',16),(53,'test',17),(54,'test',18);
/*!40000 ALTER TABLE `squad` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-12-31  8:15:34
