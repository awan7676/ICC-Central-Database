-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: localhost    Database: icc
-- ------------------------------------------------------
-- Server version	8.0.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `umpiring`
--

DROP TABLE IF EXISTS `umpiring`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `umpiring` (
  `Umpire_umpire_id` int NOT NULL,
  `Matches_match_id` int NOT NULL,
  `Matches_match_type` varchar(20) NOT NULL,
  `role` varchar(45) NOT NULL,
  PRIMARY KEY (`Umpire_umpire_id`,`Matches_match_id`,`Matches_match_type`),
  KEY `fk_Umpire_has_Matches_Umpire1_idx` (`Umpire_umpire_id`),
  KEY `fk_Umpiring_Matches1_idx` (`Matches_match_id`,`Matches_match_type`),
  CONSTRAINT `fk_Umpire_has_Matches_Umpire1` FOREIGN KEY (`Umpire_umpire_id`) REFERENCES `umpire` (`umpire_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_Umpiring_Matches1` FOREIGN KEY (`Matches_match_id`, `Matches_match_type`) REFERENCES `matches` (`match_id`, `match_type`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `umpiring_chk_1` CHECK (((`role` = _utf8mb4'1st-umpire') or (`role` = _utf8mb4'2nd-umpire') or (`role` = _utf8mb4'3rd-upmire')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `umpiring`
--

LOCK TABLES `umpiring` WRITE;
/*!40000 ALTER TABLE `umpiring` DISABLE KEYS */;
INSERT INTO `umpiring` VALUES (788,22,'odi','1st-umpire'),(789,1,'t20','2nd-umpire'),(789,3,'test','1st-umpire'),(789,11,'test','1st-umpire'),(789,21,'t20','2nd-umpire'),(789,26,'odi','1st-umpire'),(790,2,'test','1st-umpire'),(790,10,'test','1st-umpire'),(791,9,'t20','1st-umpire'),(791,17,'t20','1st-umpire'),(791,21,'t20','1st-umpire'),(792,3,'test','2nd-umpire'),(792,11,'test','2nd-umpire'),(792,27,'odi','1st-umpire'),(793,9,'t20','3rd-upmire'),(793,17,'t20','3rd-upmire'),(793,21,'t20','3rd-upmire'),(793,24,'t20','1st-umpire'),(793,27,'odi','2nd-umpire'),(794,4,'t20','1st-umpire'),(794,8,'odi','1st-umpire'),(794,12,'t20','1st-umpire'),(794,16,'odi','1st-umpire'),(794,25,'test','1st-umpire'),(794,27,'odi','3rd-upmire'),(795,2,'test','2nd-umpire'),(795,4,'t20','2nd-umpire'),(795,10,'test','2nd-umpire'),(795,12,'t20','2nd-umpire'),(795,28,'t20','1st-umpire'),(795,29,'test','1st-umpire'),(796,4,'t20','3rd-upmire'),(796,12,'t20','3rd-upmire'),(798,18,'test','1st-umpire'),(798,19,'odi','1st-umpire'),(799,6,'odi','2nd-umpire'),(799,7,'odi','2nd-umpire'),(799,14,'odi','2nd-umpire'),(799,15,'odi','2nd-umpire'),(800,1,'t20','1st-umpire'),(800,2,'test','3rd-upmire'),(800,10,'test','3rd-upmire'),(800,20,'t20','1st-umpire'),(800,22,'odi','3rd-upmire'),(801,8,'odi','2nd-umpire'),(801,16,'odi','2nd-umpire'),(802,5,'test','1st-umpire'),(802,6,'odi','3rd-upmire'),(802,7,'odi','3rd-upmire'),(802,13,'test','1st-umpire'),(802,14,'odi','3rd-upmire'),(802,15,'odi','3rd-upmire'),(802,26,'odi','2nd-umpire'),(802,28,'t20','2nd-umpire'),(803,5,'test','2nd-umpire'),(803,13,'test','2nd-umpire'),(803,18,'test','3rd-upmire'),(803,25,'test','3rd-upmire'),(804,6,'odi','1st-umpire'),(804,7,'odi','1st-umpire'),(804,14,'odi','1st-umpire'),(804,15,'odi','1st-umpire'),(805,25,'test','2nd-umpire'),(806,24,'t20','3rd-upmire'),(807,18,'test','2nd-umpire'),(807,23,'test','1st-umpire'),(808,23,'test','2nd-umpire'),(809,3,'test','3rd-upmire'),(809,11,'test','3rd-upmire'),(810,1,'t20','3rd-upmire'),(810,19,'odi','3rd-upmire'),(810,20,'t20','2nd-umpire'),(812,23,'test','3rd-upmire'),(815,26,'odi','3rd-upmire'),(816,5,'test','3rd-upmire'),(816,13,'test','3rd-upmire'),(816,19,'odi','2nd-umpire'),(817,28,'t20','3rd-upmire'),(819,29,'test','2nd-umpire'),(820,8,'odi','3rd-upmire'),(820,9,'t20','2nd-umpire'),(820,16,'odi','3rd-upmire'),(820,17,'t20','2nd-umpire'),(820,20,'t20','3rd-upmire'),(821,24,'t20','2nd-umpire'),(821,29,'test','3rd-upmire'),(822,22,'odi','2nd-umpire');
/*!40000 ALTER TABLE `umpiring` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-12-31  8:15:33
