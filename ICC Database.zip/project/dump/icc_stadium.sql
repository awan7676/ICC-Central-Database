-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: localhost    Database: icc
-- ------------------------------------------------------
-- Server version	8.0.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `stadium`
--

DROP TABLE IF EXISTS `stadium`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stadium` (
  `std_id` int NOT NULL AUTO_INCREMENT,
  `std_name` varchar(80) NOT NULL,
  `country` varchar(45) NOT NULL,
  `capacity` int NOT NULL,
  PRIMARY KEY (`std_id`),
  CONSTRAINT `stadium_chk_1` CHECK ((not((`std_name` like _utf8mb4'%[0-9]%')))),
  CONSTRAINT `stadium_chk_2` CHECK ((not((`country` like _utf8mb4'%[0-9]%')))),
  CONSTRAINT `stadium_chk_3` CHECK ((`capacity` >= 5000))
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stadium`
--

LOCK TABLES `stadium` WRITE;
/*!40000 ALTER TABLE `stadium` DISABLE KEYS */;
INSERT INTO `stadium` VALUES (1,'Gaddafi Cricket Stadium, Lahore','Pakistan',17000),(2,'Multan Cricket Stadium, Multan','Pakistan',24000),(3,'Rawalpindi Cricket Stadium, Rawalpindi','Pakistan',30000),(4,'National Stadium, Karachi','Pakistan',25000),(5,'Lords Cricket Ground, London','England',42000),(6,'Headingley Cricket Ground, Leeds','England',38000),(7,'Edgbaston Cricket Ground, Birmingham','England',20000),(8,'Trent Bridge Stadium, Nottingham','England',33000),(9,'The Oval, London','England',35000),(10,'Cardiff Wales Stadium, Cardiff','England',22000),(11,'Bristol County Ground, Bristol','England',40000),(12,'Old Trafford, Manchester','England',27000),(13,'Melbourne Cricket Ground, Melbourne','Australia',29000),(14,'Sydney Cricket Ground, Sydney','Australia',32000),(15,'The Gabba, Brisbane','Australia',34000),(16,'Adelaide Oval, Adelaide','Australia',20000),(17,'Bellerive Oval, Bellerive','Australia',17500),(18,'Eden Gardens, Kolkata','India',45000),(19,'Wankhede Stadium, Mumbai','India',32000),(20,'Maharashtra Cricekt Stadium, Pune','India',24000),(21,'M. Chinnaswamy Stadium, Bengalore','India',36000),(22,'Wellington College Ground, Wellington','New Zealand',18000),(23,'Jade Stadium, Christchurch','New Zealand',16000),(24,'Victoria Park, Auckland','New Zealand',25000),(25,'Eden Park, Auckland','New Zealand',30000),(26,'Supersport Park, Centurion','South Africa',30000),(27,'Newlands, Capetown','South Africa',19500),(28,'St George\'s Park, Port Elizabeth','South Africa',33000),(29,'Wanderers, Johannesburg','South Africa',37000),(30,'Queen\'s Park Oval, Port of Spain, Trinidad','West Indies',23000),(31,'Kensington Oval, Bridgetown, Barbados','West Indies',27000),(32,'Sabina Park-Kingston, Jamaica','West Indies',18000),(33,'Darren Sammy National Cricket Stadium, St Lucia','West Indies',28000),(34,'Dubai Cricket Stadium, Dubai','United Arab Emirates',32500),(35,'Sharjah Cricket Stadium, Sharjah','United Arab Emirates',35000),(36,'Abu Dhabi Cricket Stadium, Abu Dhabi','United Arab Emirates',28000),(37,'Shere Bangla National Stadium, Mirpur','Banglades',24000),(38,'Bangabandhu National Stadium, Dhaka','Bangladesh',16000),(39,'R. Premadasa Stadium, Colombo','Sri Lanka',25000),(40,'Pallekele International Cricket Stadium, Pallekele','Sri Lanka',18000),(41,'Gaddafi Cricket Stadium, Lahore','Pakistan',17000),(42,'Multan Cricket Stadium, Multan','Pakistan',24000),(43,'Rawalpindi Cricket Stadium, Rawalpindi','Pakistan',30000),(44,'National Stadium, Karachi','Pakistan',25000),(45,'Lords Cricket Ground, London','England',42000),(46,'Headingley Cricket Ground, Leeds','England',38000),(47,'Edgbaston Cricket Ground, Birmingham','England',20000),(48,'Trent Bridge Stadium, Nottingham','England',33000),(49,'The Oval, London','England',35000),(50,'Cardiff Wales Stadium, Cardiff','England',22000),(51,'Bristol County Ground, Bristol','England',40000),(52,'Old Trafford, Manchester','England',27000),(53,'Melbourne Cricket Ground, Melbourne','Australia',29000),(54,'Sydney Cricket Ground, Sydney','Australia',32000),(55,'The Gabba, Brisbane','Australia',34000),(56,'Adelaide Oval, Adelaide','Australia',20000),(57,'Bellerive Oval, Bellerive','Australia',17500),(58,'Eden Gardens, Kolkata','India',45000),(59,'Wankhede Stadium, Mumbai','India',32000),(60,'Maharashtra Cricekt Stadium, Pune','India',24000),(61,'M. Chinnaswamy Stadium, Bengalore','India',36000),(62,'Wellington College Ground, Wellington','New Zealand',18000),(63,'Jade Stadium, Christchurch','New Zealand',16000),(64,'Victoria Park, Auckland','New Zealand',25000),(65,'Eden Park, Auckland','New Zealand',30000),(66,'Supersport Park, Centurion','South Africa',30000),(67,'Newlands, Capetown','South Africa',19500),(68,'St George\'s Park, Port Elizabeth','South Africa',33000),(69,'Wanderers, Johannesburg','South Africa',37000),(70,'Queen\'s Park Oval, Port of Spain, Trinidad','West Indies',23000),(71,'Kensington Oval, Bridgetown, Barbados','West Indies',27000),(72,'Sabina Park-Kingston, Jamaica','West Indies',18000),(73,'Darren Sammy National Cricket Stadium, St Lucia','West Indies',28000),(74,'Dubai Cricket Stadium, Dubai','United Arab Emirates',32500),(75,'Sharjah Cricket Stadium, Sharjah','United Arab Emirates',35000),(76,'Abu Dhabi Cricket Stadium, Abu Dhabi','United Arab Emirates',28000),(77,'Shere Bangla National Stadium, Mirpur','Banglades',24000),(78,'Bangabandhu National Stadium, Dhaka','Bangladesh',16000),(79,'R. Premadasa Stadium, Colombo','Sri Lanka',25000),(80,'Pallekele International Cricket Stadium, Pallekele','Sri Lanka',18000);
/*!40000 ALTER TABLE `stadium` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-12-31  8:15:35
