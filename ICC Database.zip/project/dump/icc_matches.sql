-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: localhost    Database: icc
-- ------------------------------------------------------
-- Server version	8.0.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `matches`
--

DROP TABLE IF EXISTS `matches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `matches` (
  `match_id` int NOT NULL AUTO_INCREMENT,
  `match_type` varchar(4) NOT NULL,
  `match_year` int NOT NULL,
  `Squad_squad_id1` int NOT NULL,
  `Squad_squad_id2` int NOT NULL,
  `winner` int NOT NULL DEFAULT '0',
  `Stadium_std_id` int NOT NULL,
  PRIMARY KEY (`match_id`,`match_type`),
  KEY `fk_Matches_Squad2_idx` (`Squad_squad_id1`),
  KEY `fk_Matches_Stadium1_idx` (`Stadium_std_id`),
  KEY `fk_Matches_Squad1_idx` (`Squad_squad_id2`),
  CONSTRAINT `fk_Matches_Squad1` FOREIGN KEY (`Squad_squad_id2`) REFERENCES `squad` (`squad_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_Matches_Squad2` FOREIGN KEY (`Squad_squad_id1`) REFERENCES `squad` (`squad_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_Matches_Stadium1` FOREIGN KEY (`Stadium_std_id`) REFERENCES `stadium` (`std_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `matches_chk_1` CHECK (((`match_type` = _utf8mb4'odi') or (`match_type` = _utf8mb4't20') or (`match_type` = _utf8mb4'test'))),
  CONSTRAINT `matches_chk_2` CHECK ((`match_year` >= 1900)),
  CONSTRAINT `matches_chk_3` CHECK (((`winner` = 1) or (`winner` = 2) or (`winner` = 0) or (`winner` = -(1))))
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matches`
--

LOCK TABLES `matches` WRITE;
/*!40000 ALTER TABLE `matches` DISABLE KEYS */;
INSERT INTO `matches` VALUES (1,'t20',2002,19,28,2,4),(2,'test',2000,37,45,1,8),(3,'test',2012,42,43,0,3),(4,'t20',1998,19,30,0,1),(5,'test',2011,46,52,0,9),(6,'odi',2000,1,11,0,32),(7,'odi',2000,1,11,0,32),(8,'odi',2001,18,2,0,29),(9,'t20',2003,23,28,0,38),(10,'test',2007,37,45,0,5),(11,'test',2012,42,43,0,3),(12,'t20',1998,19,30,0,1),(13,'test',2011,46,52,0,9),(14,'odi',2000,1,11,0,32),(15,'odi',2000,1,11,0,32),(16,'odi',2001,18,2,0,29),(17,'t20',2003,23,28,0,38),(18,'test',2011,50,51,0,21),(19,'odi',1995,14,4,0,11),(20,'t20',2018,21,25,0,40),(21,'t20',2010,24,28,0,14),(22,'odi',2013,8,9,0,20),(23,'test',2012,53,38,0,14),(24,'t20',2013,32,33,0,34),(25,'test',2009,45,46,0,19),(26,'odi',2015,12,17,0,37),(27,'odi',1994,5,10,0,16),(28,'t20',2016,29,35,0,30),(29,'test',2015,45,49,0,28),(30,'odi',1992,1,3,0,8),(31,'odi',1992,1,3,0,8);
/*!40000 ALTER TABLE `matches` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-12-31  8:15:31
