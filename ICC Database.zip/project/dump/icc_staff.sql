-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: localhost    Database: icc
-- ------------------------------------------------------
-- Server version	8.0.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `staff`
--

DROP TABLE IF EXISTS `staff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `staff` (
  `staff_id` int NOT NULL,
  `team_id` int NOT NULL,
  `designation` varchar(45) NOT NULL,
  PRIMARY KEY (`staff_id`),
  KEY `fk_Staff_Team1_idx` (`team_id`),
  CONSTRAINT `fk_Staff_Person1` FOREIGN KEY (`staff_id`) REFERENCES `person` (`person_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_Staff_Team1` FOREIGN KEY (`team_id`) REFERENCES `team` (`team_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `staff_chk_1` CHECK (((`designation` = _utf8mb4'driver') or (`designation` = _utf8mb4'head coach') or (`designation` = _utf8mb4'bowling coach') or (`designation` = _utf8mb4'batting coach') or (`designation` = _utf8mb4'fielding coach') or (`designation` = _utf8mb4'cook') or (`designation` = _utf8mb4'physio') or (`designation` = _utf8mb4'doctor')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staff`
--

LOCK TABLES `staff` WRITE;
/*!40000 ALTER TABLE `staff` DISABLE KEYS */;
INSERT INTO `staff` VALUES (3,1,'cook'),(11,9,'cook'),(15,5,'cook'),(17,9,'physio'),(21,6,'cook'),(31,6,'physio'),(34,7,'cook'),(36,8,'cook'),(38,1,'physio'),(39,4,'cook'),(42,10,'cook'),(45,3,'cook'),(49,7,'physio'),(50,5,'physio'),(54,1,'doctor'),(55,4,'physio'),(57,4,'doctor'),(58,7,'doctor'),(64,7,'driver'),(67,1,'driver'),(68,6,'doctor'),(71,6,'driver'),(73,4,'driver'),(77,10,'physio'),(84,3,'physio'),(86,3,'doctor'),(96,9,'doctor'),(101,5,'doctor'),(109,9,'driver'),(113,10,'doctor'),(123,8,'physio'),(128,8,'doctor'),(133,10,'driver'),(143,5,'driver'),(144,2,'cook'),(162,8,'driver'),(164,2,'physio'),(165,2,'doctor'),(185,3,'driver'),(195,2,'driver'),(452,12,'cook'),(454,12,'physio'),(455,14,'cook'),(463,16,'cook'),(474,16,'physio'),(477,16,'doctor'),(478,14,'physio'),(480,11,'cook'),(494,12,'doctor'),(496,12,'driver'),(497,11,'physio'),(498,14,'doctor'),(500,11,'doctor'),(503,11,'driver'),(506,14,'driver'),(508,16,'driver'),(512,17,'cook'),(562,17,'physio'),(579,17,'doctor'),(588,17,'driver'),(607,18,'cook'),(611,18,'physio'),(616,18,'doctor'),(620,18,'driver'),(639,13,'cook'),(642,13,'physio'),(643,13,'doctor'),(648,13,'driver'),(708,15,'driver'),(711,15,'doctor'),(713,15,'physio'),(715,15,'cook');
/*!40000 ALTER TABLE `staff` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-12-31  8:15:31
